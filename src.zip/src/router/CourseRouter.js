import course from "../components/coursecomponent/CourseList";
import { Route, Switch } from "react-router-dom";
import AddCourse from "../components/coursecomponent/AddCourse";
import UpdateCourse from "../components/coursecomponent/UpdateCourse";
import { BrowserRouter } from "react-router-dom";
import Nav from "../components/coursecomponent/Nav";

function CourseRouter(){ 
     return(
        <div>
        <BrowserRouter>
        <Nav />
          <Switch>
            <Route path="/course" component={course} />
            <Route path="/addcourse" component={AddCourse} />
            <Route path="/updatecourse/:id" component={UpdateCourse} />
          </Switch>
        </BrowserRouter>
        </div>
     );
}

export default CourseRouter;