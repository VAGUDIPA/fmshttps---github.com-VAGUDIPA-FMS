import "./App.css";
import "bootstrap/dist/css/bootstrap.css";
import { Container } from "@material-ui/core";
import CourseRouter from "./router/CourseRouter";

 function App() {
  return (
    <div className="App">
      <Container style={{ marginTop: "68px" }}>
      <CourseRouter />  
      </Container> 
    </div>
  );
}

export default App;